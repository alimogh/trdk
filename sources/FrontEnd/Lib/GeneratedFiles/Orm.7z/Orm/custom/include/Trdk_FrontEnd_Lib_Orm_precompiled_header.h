#ifndef _TRDK_FRONTEND_LIB_ORM_PRECOMPILED_HEADER_H_CUSTOM
#define _TRDK_FRONTEND_LIB_ORM_PRECOMPILED_HEADER_H_CUSTOM

#ifdef _MSC_VER
#pragma once
#endif

/* -- Put your custom code here -- */

#endif // _TRDK_FRONTEND_LIB_ORM_PRECOMPILED_HEADER_H_CUSTOM
