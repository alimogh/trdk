/************************************************************************************************
** File created by QxEntityEditor 1.2.2 (2018/04/18 21:45) : please, do NOT modify this file ! **
************************************************************************************************/

#ifndef _TRDK_FRONTEND_LIB_ORM_TRDK_FRONTEND_ORM_ORDER_H_
#define _TRDK_FRONTEND_LIB_ORM_TRDK_FRONTEND_ORM_ORDER_H_

#include "../include/trdk_FrontEnd_Orm_TimeInForce.gen.h"

namespace trdk {
namespace FrontEnd {
namespace Orm {
class Operation;
} // namespace Orm
} // namespace FrontEnd
} // namespace trdk

namespace trdk {
namespace FrontEnd {
namespace Orm {

class TRDK_FRONTEND_LIB_ORM_EXPORT Order
{

   QX_REGISTER_FRIEND_CLASS(trdk::FrontEnd::Orm::Order)

public:

   typedef boost::shared_ptr<trdk::FrontEnd::Orm::Operation> type_Operation;

protected:

   quint64 m_Id;
   qint64 m_SubOperationId;
   QString m_RemoteId;
   QDateTime m_OrderTime;
   QDateTime m_UpdateTime;
   QString m_Symbol;
   QString m_Currency;
   QString m_TradingSystem;
   bool m_IsBuy;
   double m_Qty;
   double m_RemainingQty;
   double m_Price;
   int m_Status;
   trdk::FrontEnd::Orm::TimeInForce::enum_TimeInForce m_TimeInForce;
   QString m_AdditionalInfo;
   type_Operation m_Operation;

public:

   Order();
   Order(const quint64 & id);
   virtual ~Order();

   quint64 getId() const;
   qint64 getSubOperationId() const;
   QString getRemoteId() const;
   QDateTime getOrderTime() const;
   QDateTime getUpdateTime() const;
   QString getSymbol() const;
   QString getCurrency() const;
   QString getTradingSystem() const;
   bool getIsBuy() const;
   double getQty() const;
   double getRemainingQty() const;
   double getPrice() const;
   int getStatus() const;
   trdk::FrontEnd::Orm::TimeInForce::enum_TimeInForce getTimeInForce() const;
   QString getAdditionalInfo() const;
   type_Operation getOperation() const;

   void setId(const quint64 & val);
   void setSubOperationId(const qint64 & val);
   void setRemoteId(const QString & val);
   void setOrderTime(const QDateTime & val);
   void setUpdateTime(const QDateTime & val);
   void setSymbol(const QString & val);
   void setCurrency(const QString & val);
   void setTradingSystem(const QString & val);
   void setIsBuy(const bool & val);
   void setQty(const double & val);
   void setRemainingQty(const double & val);
   void setPrice(const double & val);
   void setStatus(const int & val);
   void setTimeInForce(const trdk::FrontEnd::Orm::TimeInForce::enum_TimeInForce & val);
   void setAdditionalInfo(const QString & val);
   void setOperation(const type_Operation & val);

   type_Operation getOperation(bool bLoadFromDatabase, const QString & sAppendRelations = QString(), QSqlDatabase * pDatabase = NULL, QSqlError * pDaoError = NULL);

public:

   static QString relation_Operation(bool key = false) { return (key ? QString("Operation") : QString("operation")); }

public:

   static QString column_Id(bool key = false) { return (key ? QString("Id") : QString("id")); }
   static QString column_SubOperationId(bool key = false) { return (key ? QString("SubOperationId") : QString("sub_operation_id")); }
   static QString column_RemoteId(bool key = false) { return (key ? QString("RemoteId") : QString("remote_id")); }
   static QString column_OrderTime(bool key = false) { return (key ? QString("OrderTime") : QString("order_time")); }
   static QString column_UpdateTime(bool key = false) { return (key ? QString("UpdateTime") : QString("update_time")); }
   static QString column_Symbol(bool key = false) { return (key ? QString("Symbol") : QString("symbol")); }
   static QString column_Currency(bool key = false) { return (key ? QString("Currency") : QString("currency")); }
   static QString column_TradingSystem(bool key = false) { return (key ? QString("TradingSystem") : QString("trading_system")); }
   static QString column_IsBuy(bool key = false) { return (key ? QString("IsBuy") : QString("is_buy")); }
   static QString column_Qty(bool key = false) { return (key ? QString("Qty") : QString("qty")); }
   static QString column_RemainingQty(bool key = false) { return (key ? QString("RemainingQty") : QString("remaining_qty")); }
   static QString column_Price(bool key = false) { return (key ? QString("Price") : QString("price")); }
   static QString column_Status(bool key = false) { return (key ? QString("Status") : QString("status")); }
   static QString column_TimeInForce(bool key = false) { return (key ? QString("TimeInForce") : QString("time_in_force")); }
   static QString column_AdditionalInfo(bool key = false) { return (key ? QString("AdditionalInfo") : QString("additional_info")); }

public:

   static QString table_name(bool key = false) { return (key ? QString("Order") : QString("order_")); }

};

typedef std::shared_ptr<Order> Order_ptr;
typedef qx::QxCollection<quint64, Order_ptr> list_of_Order;
typedef std::shared_ptr<list_of_Order> list_of_Order_ptr;

} // namespace Orm
} // namespace FrontEnd
} // namespace trdk

QX_REGISTER_PRIMARY_KEY(trdk::FrontEnd::Orm::Order, quint64)
QX_REGISTER_COMPLEX_CLASS_NAME_HPP_TRDK_FRONTEND_LIB_ORM(trdk::FrontEnd::Orm::Order, qx::trait::no_base_class_defined, 0, trdk_FrontEnd_Orm_Order)

#include "../include/trdk_FrontEnd_Orm_Operation.gen.h"

#endif // _TRDK_FRONTEND_LIB_ORM_TRDK_FRONTEND_ORM_ORDER_H_
