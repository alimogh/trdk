/************************************************************************************************
** File created by QxEntityEditor 1.2.2 (2018/04/18 19:51) : please, do NOT modify this file ! **
************************************************************************************************/

#ifndef _TRDK_FRONTEND_LIB_ORM_TRDK_FRONTEND_ORM_OPERATION_H_
#define _TRDK_FRONTEND_LIB_ORM_TRDK_FRONTEND_ORM_OPERATION_H_

#include "../include/trdk_FrontEnd_Orm_OperationStatus.gen.h"

namespace trdk {
namespace FrontEnd {
namespace Orm {
class StrategyInstance;
} // namespace Orm
} // namespace FrontEnd
} // namespace trdk
namespace trdk {
namespace FrontEnd {
namespace Orm {
class Order;
} // namespace Orm
} // namespace FrontEnd
} // namespace trdk
namespace trdk {
namespace FrontEnd {
namespace Orm {
class Pnl;
} // namespace Orm
} // namespace FrontEnd
} // namespace trdk

namespace trdk {
namespace FrontEnd {
namespace Orm {

class TRDK_FRONTEND_LIB_ORM_EXPORT Operation
{

   QX_REGISTER_FRIEND_CLASS(trdk::FrontEnd::Orm::Operation)

public:

   typedef boost::shared_ptr<trdk::FrontEnd::Orm::StrategyInstance> type_StrategyInstance;
   typedef std::vector<boost::shared_ptr<trdk::FrontEnd::Orm::Order> > type_Orders;
   typedef std::vector<boost::shared_ptr<trdk::FrontEnd::Orm::Pnl> > type_Pnl;

protected:

   QUuid m_Id;
   trdk::FrontEnd::Orm::OperationStatus::enum_OperationStatus m_Status;
   QDateTime m_StartTime;
   QDateTime m_EndTime;
   type_StrategyInstance m_StrategyInstance;
   type_Orders m_Orders;
   type_Pnl m_Pnl;

public:

   Operation();
   Operation(const QUuid & id);
   virtual ~Operation();

   QUuid getId() const;
   trdk::FrontEnd::Orm::OperationStatus::enum_OperationStatus getStatus() const;
   QDateTime getStartTime() const;
   QDateTime getEndTime() const;
   type_StrategyInstance getStrategyInstance() const;
   type_Orders getOrders() const;
   type_Orders & Orders();
   const type_Orders & Orders() const;
   type_Pnl getPnl() const;
   type_Pnl & Pnl();
   const type_Pnl & Pnl() const;

   void setId(const QUuid & val);
   void setStatus(const trdk::FrontEnd::Orm::OperationStatus::enum_OperationStatus & val);
   void setStartTime(const QDateTime & val);
   void setEndTime(const QDateTime & val);
   void setStrategyInstance(const type_StrategyInstance & val);
   void setOrders(const type_Orders & val);
   void setPnl(const type_Pnl & val);

   type_StrategyInstance getStrategyInstance(bool bLoadFromDatabase, const QString & sAppendRelations = QString(), QSqlDatabase * pDatabase = NULL, QSqlError * pDaoError = NULL);
   type_Orders getOrders(bool bLoadFromDatabase, const QString & sAppendRelations = QString(), QSqlDatabase * pDatabase = NULL, QSqlError * pDaoError = NULL);
   type_Orders & Orders(bool bLoadFromDatabase, const QString & sAppendRelations = QString(), QSqlDatabase * pDatabase = NULL, QSqlError * pDaoError = NULL);
   type_Pnl getPnl(bool bLoadFromDatabase, const QString & sAppendRelations = QString(), QSqlDatabase * pDatabase = NULL, QSqlError * pDaoError = NULL);
   type_Pnl & Pnl(bool bLoadFromDatabase, const QString & sAppendRelations = QString(), QSqlDatabase * pDatabase = NULL, QSqlError * pDaoError = NULL);

public:

   static QString relation_StrategyInstance(bool key = false) { return (key ? QString("StrategyInstance") : QString("strategyInstance")); }
   static QString relation_Orders(bool key = false) { return (key ? QString("Orders") : QString("orders")); }
   static QString relation_Pnl(bool key = false) { Q_UNUSED(key); return "Pnl"; }

public:

   static QString column_Id(bool key = false) { return (key ? QString("Id") : QString("id")); }
   static QString column_Status(bool key = false) { return (key ? QString("Status") : QString("status")); }
   static QString column_StartTime(bool key = false) { return (key ? QString("StartTime") : QString("start_time")); }
   static QString column_EndTime(bool key = false) { return (key ? QString("EndTime") : QString("end_time")); }

public:

   static QString table_name(bool key = false) { return (key ? QString("Operation") : QString("operation")); }

};

typedef std::shared_ptr<Operation> Operation_ptr;
typedef qx::QxCollection<QUuid, Operation_ptr> list_of_Operation;
typedef std::shared_ptr<list_of_Operation> list_of_Operation_ptr;

} // namespace Orm
} // namespace FrontEnd
} // namespace trdk

QX_REGISTER_PRIMARY_KEY(trdk::FrontEnd::Orm::Operation, QUuid)
QX_REGISTER_COMPLEX_CLASS_NAME_HPP_TRDK_FRONTEND_LIB_ORM(trdk::FrontEnd::Orm::Operation, qx::trait::no_base_class_defined, 0, trdk_FrontEnd_Orm_Operation)

#include "../include/trdk_FrontEnd_Orm_StrategyInstance.gen.h"
#include "../include/trdk_FrontEnd_Orm_Order.gen.h"
#include "../include/trdk_FrontEnd_Orm_Pnl.gen.h"

#endif // _TRDK_FRONTEND_LIB_ORM_TRDK_FRONTEND_ORM_OPERATION_H_
