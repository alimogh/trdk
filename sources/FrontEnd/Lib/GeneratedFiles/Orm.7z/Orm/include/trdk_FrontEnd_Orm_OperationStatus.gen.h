/************************************************************************************************
** File created by QxEntityEditor 1.2.2 (2018/04/17 17:41) : please, do NOT modify this file ! **
************************************************************************************************/

#ifndef _TRDK_FRONTEND_LIB_ORM_TRDK_FRONTEND_ORM_OPERATIONSTATUS_H_
#define _TRDK_FRONTEND_LIB_ORM_TRDK_FRONTEND_ORM_OPERATIONSTATUS_H_

#ifdef _QX_NO_PRECOMPILED_HEADER
#ifndef Q_MOC_RUN
#include "../include/Trdk_FrontEnd_Lib_Orm_precompiled_header.gen.h" // Need to include precompiled header for the generated moc file
#endif // Q_MOC_RUN
#endif // _QX_NO_PRECOMPILED_HEADER

namespace trdk {
namespace FrontEnd {
namespace Orm {

class TRDK_FRONTEND_LIB_ORM_EXPORT OperationStatus
{

public:

   enum enum_OperationStatus
   {
      ACTIVE = 0,
      CANCELED = 1,
      PROFIT = 2,
      LOSS = 3,
      ERROR = 4,
      COMPLETED = 5,
      numberOfStatuses = 6
   };

private:

   OperationStatus();
   virtual ~OperationStatus();

};

} // namespace Orm
} // namespace FrontEnd
} // namespace trdk

#endif // _TRDK_FRONTEND_LIB_ORM_TRDK_FRONTEND_ORM_OPERATIONSTATUS_H_
