/************************************************************************************************
** File created by QxEntityEditor 1.2.2 (2018/04/17 19:05) : please, do NOT modify this file ! **
************************************************************************************************/

#ifndef _TRDK_FRONTEND_LIB_ORM_TRDK_FRONTEND_ORM_TIMEONFORCE_H_
#define _TRDK_FRONTEND_LIB_ORM_TRDK_FRONTEND_ORM_TIMEONFORCE_H_

#ifdef _QX_NO_PRECOMPILED_HEADER
#ifndef Q_MOC_RUN
#include "../include/Trdk_FrontEnd_Lib_Orm_precompiled_header.gen.h" // Need to include precompiled header for the generated moc file
#endif // Q_MOC_RUN
#endif // _QX_NO_PRECOMPILED_HEADER

namespace trdk {
namespace FrontEnd {
namespace Orm {

class TRDK_FRONTEND_LIB_ORM_EXPORT TimeOnForce
{

public:

   enum enum_TimeOnForce
   {
      TIME_IN_FORCE_DAY = 0,
      TIME_IN_FORCE_GTC = 1,
      TIME_IN_FORCE_OPG = 2,
      TIME_IN_FORCE_IOC = 3,
      TIME_IN_FORCE_FOK = 4,
      numberOfTimeInForces = 5
   };

private:

   TimeOnForce();
   virtual ~TimeOnForce();

};

} // namespace Orm
} // namespace FrontEnd
} // namespace trdk

#endif // _TRDK_FRONTEND_LIB_ORM_TRDK_FRONTEND_ORM_TIMEONFORCE_H_
