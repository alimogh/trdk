/************************************************************************************************
** File created by QxEntityEditor 1.2.2 (2018/03/19 22:42) : please, do NOT modify this file ! **
************************************************************************************************/

#ifndef _TRDK_FRONTEND_LIB_ORM_PRECOMPILED_HEADER_H_
#define _TRDK_FRONTEND_LIB_ORM_PRECOMPILED_HEADER_H_

#ifdef _MSC_VER
#pragma once
#endif

#include <QxOrm.h>

#include "../include/Trdk_FrontEnd_Lib_Orm_export.gen.h"

#include "../custom/include/Trdk_FrontEnd_Lib_Orm_precompiled_header.h"

#endif // _TRDK_FRONTEND_LIB_ORM_PRECOMPILED_HEADER_H_
