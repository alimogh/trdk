/************************************************************************************************
** File created by QxEntityEditor 1.2.2 (2018/04/17 19:30) : please, do NOT modify this file ! **
************************************************************************************************/

#ifndef _TRDK_FRONTEND_LIB_ORM_ALL_INCLUDE_H_
#define _TRDK_FRONTEND_LIB_ORM_ALL_INCLUDE_H_

#ifdef _MSC_VER
#pragma once
#endif

#include "../include/Trdk_FrontEnd_Lib_Orm_precompiled_header.gen.h"

#include "../include/trdk_FrontEnd_Orm_Operation.gen.h"
#include "../include/trdk_FrontEnd_Orm_Order.gen.h"
#include "../include/trdk_FrontEnd_Orm_Pnl.gen.h"
#include "../include/trdk_FrontEnd_Orm_StrategyInstance.gen.h"
#include "../include/trdk_FrontEnd_Orm_OperationStatus.gen.h"
#include "../include/trdk_FrontEnd_Orm_TimeInForce.gen.h"

#endif // _TRDK_FRONTEND_LIB_ORM_ALL_INCLUDE_H_
