/************************************************************************************************
** File created by QxEntityEditor 1.2.2 (2018/03/20 02:02) : please, do NOT modify this file ! **
************************************************************************************************/

#ifndef _TRDK_FRONTEND_LIB_ORM_TRDK_FRONTEND_LIB_ORM_OPERATION_H_
#define _TRDK_FRONTEND_LIB_ORM_TRDK_FRONTEND_LIB_ORM_OPERATION_H_

#include "../include/trdk_FrontEnd_Lib_Orm_OperationStatus.gen.h"

namespace trdk {
namespace FrontEnd {
namespace Lib {
namespace Orm {
class Strategy;
} // namespace Orm
} // namespace Lib
} // namespace FrontEnd
} // namespace trdk
namespace trdk {
namespace FrontEnd {
namespace Lib {
namespace Orm {
class Order;
} // namespace Orm
} // namespace Lib
} // namespace FrontEnd
} // namespace trdk
namespace trdk {
namespace FrontEnd {
namespace Lib {
namespace Orm {
class Pnl;
} // namespace Orm
} // namespace Lib
} // namespace FrontEnd
} // namespace trdk

namespace trdk {
namespace FrontEnd {
namespace Lib {
namespace Orm {

class TRDK_FRONTEND_LIB_ORM_EXPORT Operation
{

   QX_REGISTER_FRIEND_CLASS(trdk::FrontEnd::Lib::Orm::Operation)

public:

   typedef boost::shared_ptr<trdk::FrontEnd::Lib::Orm::Strategy> type_Strategy;
   typedef std::vector<boost::shared_ptr<trdk::FrontEnd::Lib::Orm::Order> > type_Orders;
   typedef std::vector<boost::shared_ptr<trdk::FrontEnd::Lib::Orm::Pnl> > type_Pnl;

protected:

   QUuid m_Id;
   trdk::FrontEnd::Lib::Orm::OperationStatus::enum_OperationStatus m_Status;
   QDateTime m_StartTime;
   QDateTime m_EndTime;
   type_Strategy m_Strategy;
   type_Orders m_Orders;
   type_Pnl m_Pnl;

public:

   Operation();
   Operation(const QUuid & id);
   virtual ~Operation();

   QUuid getId() const;
   trdk::FrontEnd::Lib::Orm::OperationStatus::enum_OperationStatus getStatus() const;
   QDateTime getStartTime() const;
   QDateTime getEndTime() const;
   type_Strategy getStrategy() const;
   type_Orders getOrders() const;
   type_Orders & Orders();
   const type_Orders & Orders() const;
   type_Pnl getPnl() const;
   type_Pnl & Pnl();
   const type_Pnl & Pnl() const;

   void setId(const QUuid & val);
   void setStatus(const trdk::FrontEnd::Lib::Orm::OperationStatus::enum_OperationStatus & val);
   void setStartTime(const QDateTime & val);
   void setEndTime(const QDateTime & val);
   void setStrategy(const type_Strategy & val);
   void setOrders(const type_Orders & val);
   void setPnl(const type_Pnl & val);

   type_Strategy getStrategy(bool bLoadFromDatabase, const QString & sAppendRelations = QString(), QSqlDatabase * pDatabase = NULL, QSqlError * pDaoError = NULL);
   type_Orders getOrders(bool bLoadFromDatabase, const QString & sAppendRelations = QString(), QSqlDatabase * pDatabase = NULL, QSqlError * pDaoError = NULL);
   type_Orders & Orders(bool bLoadFromDatabase, const QString & sAppendRelations = QString(), QSqlDatabase * pDatabase = NULL, QSqlError * pDaoError = NULL);
   type_Pnl getPnl(bool bLoadFromDatabase, const QString & sAppendRelations = QString(), QSqlDatabase * pDatabase = NULL, QSqlError * pDaoError = NULL);
   type_Pnl & Pnl(bool bLoadFromDatabase, const QString & sAppendRelations = QString(), QSqlDatabase * pDatabase = NULL, QSqlError * pDaoError = NULL);

public:

   static QString relation_Strategy(bool key = false) { return (key ? QString("Strategy") : QString("strategyInstance")); }
   static QString relation_Orders(bool key = false) { return (key ? QString("Orders") : QString("orders")); }
   static QString relation_Pnl(bool key = false) { Q_UNUSED(key); return "Pnl"; }

public:

   static QString column_Id(bool key = false) { return (key ? QString("Id") : QString("id")); }
   static QString column_Status(bool key = false) { return (key ? QString("Status") : QString("status")); }
   static QString column_StartTime(bool key = false) { return (key ? QString("StartTime") : QString("startTime")); }
   static QString column_EndTime(bool key = false) { return (key ? QString("EndTime") : QString("endTime")); }

public:

   static QString table_name(bool key = false) { return (key ? QString("Operation") : QString("t_Operation")); }

};

typedef std::shared_ptr<Operation> Operation_ptr;
typedef qx::QxCollection<QUuid, Operation_ptr> list_of_Operation;
typedef std::shared_ptr<list_of_Operation> list_of_Operation_ptr;

} // namespace Orm
} // namespace Lib
} // namespace FrontEnd
} // namespace trdk

QX_REGISTER_PRIMARY_KEY(trdk::FrontEnd::Lib::Orm::Operation, QUuid)
QX_REGISTER_COMPLEX_CLASS_NAME_HPP_TRDK_FRONTEND_LIB_ORM(trdk::FrontEnd::Lib::Orm::Operation, qx::trait::no_base_class_defined, 0, trdk_FrontEnd_Lib_Orm_Operation)

#include "../include/trdk_FrontEnd_Lib_Orm_Strategy.gen.h"
#include "../include/trdk_FrontEnd_Lib_Orm_Order.gen.h"
#include "../include/trdk_FrontEnd_Lib_Orm_Pnl.gen.h"

#endif // _TRDK_FRONTEND_LIB_ORM_TRDK_FRONTEND_LIB_ORM_OPERATION_H_
