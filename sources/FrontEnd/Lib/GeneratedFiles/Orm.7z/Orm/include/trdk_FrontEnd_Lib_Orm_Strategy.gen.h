/************************************************************************************************
** File created by QxEntityEditor 1.2.2 (2018/03/20 02:02) : please, do NOT modify this file ! **
************************************************************************************************/

#ifndef _TRDK_FRONTEND_LIB_ORM_TRDK_FRONTEND_LIB_ORM_STRATEGY_H_
#define _TRDK_FRONTEND_LIB_ORM_TRDK_FRONTEND_LIB_ORM_STRATEGY_H_

namespace trdk {
namespace FrontEnd {
namespace Lib {
namespace Orm {
class Operation;
} // namespace Orm
} // namespace Lib
} // namespace FrontEnd
} // namespace trdk

namespace trdk {
namespace FrontEnd {
namespace Lib {
namespace Orm {

class TRDK_FRONTEND_LIB_ORM_EXPORT Strategy
{

   QX_REGISTER_FRIEND_CLASS(trdk::FrontEnd::Lib::Orm::Strategy)

public:

   typedef qx::QxCollection<QUuid, boost::shared_ptr<trdk::FrontEnd::Lib::Orm::Operation> > type_Operations;

protected:

   QUuid m_Id;
   QString m_Name;
   type_Operations m_Operations;

public:

   Strategy();
   Strategy(const QUuid & id);
   virtual ~Strategy();

   QUuid getId() const;
   QString getName() const;
   type_Operations getOperations() const;
   type_Operations & Operations();
   const type_Operations & Operations() const;

   void setId(const QUuid & val);
   void setName(const QString & val);
   void setOperations(const type_Operations & val);

   type_Operations getOperations(bool bLoadFromDatabase, const QString & sAppendRelations = QString(), QSqlDatabase * pDatabase = NULL, QSqlError * pDaoError = NULL);
   type_Operations & Operations(bool bLoadFromDatabase, const QString & sAppendRelations = QString(), QSqlDatabase * pDatabase = NULL, QSqlError * pDaoError = NULL);

public:

   static QString relation_Operations(bool key = false) { return (key ? QString("Operations") : QString("operations")); }

public:

   static QString column_Id(bool key = false) { return (key ? QString("Id") : QString("id")); }
   static QString column_Name(bool key = false) { return (key ? QString("Name") : QString("name")); }

public:

   static QString table_name(bool key = false) { return (key ? QString("Strategy") : QString("t_Strategy")); }

};

typedef std::shared_ptr<Strategy> Strategy_ptr;
typedef qx::QxCollection<QUuid, Strategy_ptr> list_of_Strategy;
typedef std::shared_ptr<list_of_Strategy> list_of_Strategy_ptr;

} // namespace Orm
} // namespace Lib
} // namespace FrontEnd
} // namespace trdk

QX_REGISTER_PRIMARY_KEY(trdk::FrontEnd::Lib::Orm::Strategy, QUuid)
QX_REGISTER_COMPLEX_CLASS_NAME_HPP_TRDK_FRONTEND_LIB_ORM(trdk::FrontEnd::Lib::Orm::Strategy, qx::trait::no_base_class_defined, 0, trdk_FrontEnd_Lib_Orm_Strategy)

#include "../include/trdk_FrontEnd_Lib_Orm_Operation.gen.h"

#endif // _TRDK_FRONTEND_LIB_ORM_TRDK_FRONTEND_LIB_ORM_STRATEGY_H_
