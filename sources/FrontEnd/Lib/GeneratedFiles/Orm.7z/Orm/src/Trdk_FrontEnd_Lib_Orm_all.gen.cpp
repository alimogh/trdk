#ifdef _QX_UNITY_BUILD

#include "../src/trdk_FrontEnd_Orm_Operation.gen.cpp"
#include "../src/trdk_FrontEnd_Orm_Order.gen.cpp"
#include "../src/trdk_FrontEnd_Orm_Pnl.gen.cpp"
#include "../src/trdk_FrontEnd_Orm_StrategyInstance.gen.cpp"

#include "../src/trdk_FrontEnd_Orm_OperationStatus.gen.cpp"
#include "../src/trdk_FrontEnd_Orm_TimeInForce.gen.cpp"

#include "../src/Trdk_FrontEnd_Lib_Orm_main.gen.cpp"

#endif // _QX_UNITY_BUILD
