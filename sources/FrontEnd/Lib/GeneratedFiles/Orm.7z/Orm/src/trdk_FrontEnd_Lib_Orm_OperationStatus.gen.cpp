/************************************************************************************************
** File created by QxEntityEditor 1.2.2 (2018/03/19 22:42) : please, do NOT modify this file ! **
************************************************************************************************/

#include "../include/Trdk_FrontEnd_Lib_Orm_precompiled_header.gen.h"

#include "../include/trdk_FrontEnd_Lib_Orm_OperationStatus.gen.h"

#include <QxOrm_Impl.h>

namespace trdk {
namespace FrontEnd {
namespace Lib {
namespace Orm {

OperationStatus::OperationStatus() { ; }

OperationStatus::~OperationStatus() { ; }

} // namespace Orm
} // namespace Lib
} // namespace FrontEnd
} // namespace trdk
