/************************************************************************************************
** File created by QxEntityEditor 1.2.2 (2018/03/19 23:17) : please, do NOT modify this file ! **
************************************************************************************************/

#include "../include/Trdk_FrontEnd_Lib_Orm_precompiled_header.gen.h"

#include "../include/trdk_FrontEnd_Lib_Orm_StrategyInstance.gen.h"
#include "../include/trdk_FrontEnd_Lib_Orm_Operation.gen.h"

#include <QxOrm_Impl.h>

QX_REGISTER_COMPLEX_CLASS_NAME_CPP_TRDK_FRONTEND_LIB_ORM(trdk::FrontEnd::Lib::Orm::StrategyInstance, trdk_FrontEnd_Lib_Orm_StrategyInstance)

namespace qx {

template <>
void register_class(QxClass<trdk::FrontEnd::Lib::Orm::StrategyInstance> & t)
{
   qx::IxDataMember * pData = NULL; Q_UNUSED(pData);
   qx::IxSqlRelation * pRelation = NULL; Q_UNUSED(pRelation);
   qx::IxFunction * pFct = NULL; Q_UNUSED(pFct);
   qx::IxValidator * pValidator = NULL; Q_UNUSED(pValidator);

   t.setName("t_StrategyInstance");

   pData = t.id(& trdk::FrontEnd::Lib::Orm::StrategyInstance::m_Id, "Id", 0);
   pData->setName("id");

   pData = t.data(& trdk::FrontEnd::Lib::Orm::StrategyInstance::m_StrategyId, "StrategyId", 0, true, true);
   pData->setName("strategyId");
   pData = t.data(& trdk::FrontEnd::Lib::Orm::StrategyInstance::m_Name, "Name", 0, true, true);
   pData->setName("name");

   pRelation = t.relationOneToMany(& trdk::FrontEnd::Lib::Orm::StrategyInstance::m_Operations, "Operations", "StrategyInstance", 0);
   pRelation->getDataMember()->setName("operations");

   qx::QxValidatorX<trdk::FrontEnd::Lib::Orm::StrategyInstance> * pAllValidator = t.getAllValidator(); Q_UNUSED(pAllValidator);
}

} // namespace qx

namespace trdk {
namespace FrontEnd {
namespace Lib {
namespace Orm {

StrategyInstance::StrategyInstance() : m_Id(0) { ; }

StrategyInstance::StrategyInstance(const quint64 & id) : m_Id(id) { ; }

StrategyInstance::~StrategyInstance() { ; }

quint64 StrategyInstance::getId() const { return m_Id; }

QUuid StrategyInstance::getStrategyId() const { return m_StrategyId; }

QString StrategyInstance::getName() const { return m_Name; }

StrategyInstance::type_Operations StrategyInstance::getOperations() const { return m_Operations; }

StrategyInstance::type_Operations & StrategyInstance::Operations() { return m_Operations; }

const StrategyInstance::type_Operations & StrategyInstance::Operations() const { return m_Operations; }

void StrategyInstance::setId(const quint64 & val) { m_Id = val; }

void StrategyInstance::setStrategyId(const QUuid & val) { m_StrategyId = val; }

void StrategyInstance::setName(const QString & val) { m_Name = val; }

void StrategyInstance::setOperations(const StrategyInstance::type_Operations & val) { m_Operations = val; }

StrategyInstance::type_Operations StrategyInstance::getOperations(bool bLoadFromDatabase, const QString & sAppendRelations /* = QString() */, QSqlDatabase * pDatabase /* = NULL */, QSqlError * pDaoError /* = NULL */)
{
   if (pDaoError) { (* pDaoError) = QSqlError(); }
   if (! bLoadFromDatabase) { return getOperations(); }
   QString sRelation = "{Id} | Operations";
   if (! sAppendRelations.isEmpty() && ! sAppendRelations.startsWith("->") && ! sAppendRelations.startsWith(">>")) { sRelation += "->" + sAppendRelations; }
   else if (! sAppendRelations.isEmpty()) { sRelation += sAppendRelations; }
   trdk::FrontEnd::Lib::Orm::StrategyInstance tmp;
   tmp.m_Id = this->m_Id;
   QSqlError daoError = qx::dao::fetch_by_id_with_relation(sRelation, tmp, pDatabase);
   if (! daoError.isValid()) { this->m_Operations = tmp.m_Operations; }
   if (pDaoError) { (* pDaoError) = daoError; }
   return m_Operations;
}

StrategyInstance::type_Operations & StrategyInstance::Operations(bool bLoadFromDatabase, const QString & sAppendRelations /* = QString() */, QSqlDatabase * pDatabase /* = NULL */, QSqlError * pDaoError /* = NULL */)
{
   if (pDaoError) { (* pDaoError) = QSqlError(); }
   if (! bLoadFromDatabase) { return Operations(); }
   QString sRelation = "{Id} | Operations";
   if (! sAppendRelations.isEmpty() && ! sAppendRelations.startsWith("->") && ! sAppendRelations.startsWith(">>")) { sRelation += "->" + sAppendRelations; }
   else if (! sAppendRelations.isEmpty()) { sRelation += sAppendRelations; }
   trdk::FrontEnd::Lib::Orm::StrategyInstance tmp;
   tmp.m_Id = this->m_Id;
   QSqlError daoError = qx::dao::fetch_by_id_with_relation(sRelation, tmp, pDatabase);
   if (! daoError.isValid()) { this->m_Operations = tmp.m_Operations; }
   if (pDaoError) { (* pDaoError) = daoError; }
   return m_Operations;
}

} // namespace Orm
} // namespace Lib
} // namespace FrontEnd
} // namespace trdk
