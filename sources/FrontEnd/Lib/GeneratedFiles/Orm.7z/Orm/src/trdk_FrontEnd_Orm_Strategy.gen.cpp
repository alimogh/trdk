/************************************************************************************************
** File created by QxEntityEditor 1.2.2 (2018/03/26 22:50) : please, do NOT modify this file ! **
************************************************************************************************/

#include "../include/Trdk_FrontEnd_Lib_Orm_precompiled_header.gen.h"

#include "../include/trdk_FrontEnd_Orm_Strategy.gen.h"
#include "../include/trdk_FrontEnd_Orm_Operation.gen.h"

#include <QxOrm_Impl.h>

QX_REGISTER_COMPLEX_CLASS_NAME_CPP_TRDK_FRONTEND_LIB_ORM(trdk::FrontEnd::Orm::Strategy, trdk_FrontEnd_Orm_Strategy)

namespace qx {

template <>
void register_class(QxClass<trdk::FrontEnd::Orm::Strategy> & t)
{
   qx::IxDataMember * pData = NULL; Q_UNUSED(pData);
   qx::IxSqlRelation * pRelation = NULL; Q_UNUSED(pRelation);
   qx::IxFunction * pFct = NULL; Q_UNUSED(pFct);
   qx::IxValidator * pValidator = NULL; Q_UNUSED(pValidator);

   t.setName("t_Strategy");

   pData = t.id(& trdk::FrontEnd::Orm::Strategy::m_Id, "Id", 0);
   pData->setName("id");

   pData = t.data(& trdk::FrontEnd::Orm::Strategy::m_Name, "Name", 0, true, true);
   pData->setName("name");
   pData = t.data(& trdk::FrontEnd::Orm::Strategy::m_IsActive, "IsActive", 0, true, true);
   pData->setIsIndex(true);
   pData = t.data(& trdk::FrontEnd::Orm::Strategy::m_Config, "Config", 0, true, true);

   pRelation = t.relationOneToMany(& trdk::FrontEnd::Orm::Strategy::m_Operations, "Operations", "Strategy", 0);
   pRelation->getDataMember()->setName("operations");

   qx::QxValidatorX<trdk::FrontEnd::Orm::Strategy> * pAllValidator = t.getAllValidator(); Q_UNUSED(pAllValidator);
}

} // namespace qx

namespace trdk {
namespace FrontEnd {
namespace Orm {

Strategy::Strategy() : m_IsActive(false) { ; }

Strategy::Strategy(const QUuid & id) : m_Id(id), m_IsActive(false) { ; }

Strategy::~Strategy() { ; }

QUuid Strategy::getId() const { return m_Id; }

QString Strategy::getName() const { return m_Name; }

bool Strategy::getIsActive() const { return m_IsActive; }

QString Strategy::getConfig() const { return m_Config; }

Strategy::type_Operations Strategy::getOperations() const { return m_Operations; }

Strategy::type_Operations & Strategy::Operations() { return m_Operations; }

const Strategy::type_Operations & Strategy::Operations() const { return m_Operations; }

void Strategy::setId(const QUuid & val) { m_Id = val; }

void Strategy::setName(const QString & val) { m_Name = val; }

void Strategy::setIsActive(const bool & val) { m_IsActive = val; }

void Strategy::setConfig(const QString & val) { m_Config = val; }

void Strategy::setOperations(const Strategy::type_Operations & val) { m_Operations = val; }

Strategy::type_Operations Strategy::getOperations(bool bLoadFromDatabase, const QString & sAppendRelations /* = QString() */, QSqlDatabase * pDatabase /* = NULL */, QSqlError * pDaoError /* = NULL */)
{
   if (pDaoError) { (* pDaoError) = QSqlError(); }
   if (! bLoadFromDatabase) { return getOperations(); }
   QString sRelation = "{Id} | Operations";
   if (! sAppendRelations.isEmpty() && ! sAppendRelations.startsWith("->") && ! sAppendRelations.startsWith(">>")) { sRelation += "->" + sAppendRelations; }
   else if (! sAppendRelations.isEmpty()) { sRelation += sAppendRelations; }
   trdk::FrontEnd::Orm::Strategy tmp;
   tmp.m_Id = this->m_Id;
   QSqlError daoError = qx::dao::fetch_by_id_with_relation(sRelation, tmp, pDatabase);
   if (! daoError.isValid()) { this->m_Operations = tmp.m_Operations; }
   if (pDaoError) { (* pDaoError) = daoError; }
   return m_Operations;
}

Strategy::type_Operations & Strategy::Operations(bool bLoadFromDatabase, const QString & sAppendRelations /* = QString() */, QSqlDatabase * pDatabase /* = NULL */, QSqlError * pDaoError /* = NULL */)
{
   if (pDaoError) { (* pDaoError) = QSqlError(); }
   if (! bLoadFromDatabase) { return Operations(); }
   QString sRelation = "{Id} | Operations";
   if (! sAppendRelations.isEmpty() && ! sAppendRelations.startsWith("->") && ! sAppendRelations.startsWith(">>")) { sRelation += "->" + sAppendRelations; }
   else if (! sAppendRelations.isEmpty()) { sRelation += sAppendRelations; }
   trdk::FrontEnd::Orm::Strategy tmp;
   tmp.m_Id = this->m_Id;
   QSqlError daoError = qx::dao::fetch_by_id_with_relation(sRelation, tmp, pDatabase);
   if (! daoError.isValid()) { this->m_Operations = tmp.m_Operations; }
   if (pDaoError) { (* pDaoError) = daoError; }
   return m_Operations;
}

} // namespace Orm
} // namespace FrontEnd
} // namespace trdk
