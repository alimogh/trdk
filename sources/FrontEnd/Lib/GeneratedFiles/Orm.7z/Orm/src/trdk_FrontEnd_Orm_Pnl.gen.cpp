/************************************************************************************************
** File created by QxEntityEditor 1.2.2 (2018/04/18 19:51) : please, do NOT modify this file ! **
************************************************************************************************/

#include "../include/Trdk_FrontEnd_Lib_Orm_precompiled_header.gen.h"

#include "../include/trdk_FrontEnd_Orm_Pnl.gen.h"
#include "../include/trdk_FrontEnd_Orm_Operation.gen.h"

#include <QxOrm_Impl.h>

QX_REGISTER_COMPLEX_CLASS_NAME_CPP_TRDK_FRONTEND_LIB_ORM(trdk::FrontEnd::Orm::Pnl, trdk_FrontEnd_Orm_Pnl)

namespace qx {

template <>
void register_class(QxClass<trdk::FrontEnd::Orm::Pnl> & t)
{
   qx::IxDataMember * pData = NULL; Q_UNUSED(pData);
   qx::IxSqlRelation * pRelation = NULL; Q_UNUSED(pRelation);
   qx::IxFunction * pFct = NULL; Q_UNUSED(pFct);
   qx::IxValidator * pValidator = NULL; Q_UNUSED(pValidator);

   t.setName("pnl");

   pData = t.id(& trdk::FrontEnd::Orm::Pnl::m_Id, "Id", 0);
   pData->setName("id");

   pData = t.data(& trdk::FrontEnd::Orm::Pnl::m_Symbol, "Symbol", 0, true, true);
   pData->setName("symbol");
   pData = t.data(& trdk::FrontEnd::Orm::Pnl::m_FinancialResult, "FinancialResult", 0, true, true);
   pData->setName("financial_result");
   pData = t.data(& trdk::FrontEnd::Orm::Pnl::m_Commission, "Commission", 0, true, true);
   pData->setName("commission");

   pRelation = t.relationManyToOne(& trdk::FrontEnd::Orm::Pnl::m_Operation, "Operation", 0);

   qx::QxValidatorX<trdk::FrontEnd::Orm::Pnl> * pAllValidator = t.getAllValidator(); Q_UNUSED(pAllValidator);
}

} // namespace qx

namespace trdk {
namespace FrontEnd {
namespace Orm {

Pnl::Pnl() : m_Id(0), m_FinancialResult(0), m_Commission(0) { ; }

Pnl::Pnl(const quint64 & id) : m_Id(id), m_FinancialResult(0), m_Commission(0) { ; }

Pnl::~Pnl() { ; }

quint64 Pnl::getId() const { return m_Id; }

QString Pnl::getSymbol() const { return m_Symbol; }

double Pnl::getFinancialResult() const { return m_FinancialResult; }

double Pnl::getCommission() const { return m_Commission; }

Pnl::type_Operation Pnl::getOperation() const { return m_Operation; }

void Pnl::setId(const quint64 & val) { m_Id = val; }

void Pnl::setSymbol(const QString & val) { m_Symbol = val; }

void Pnl::setFinancialResult(const double & val) { m_FinancialResult = val; }

void Pnl::setCommission(const double & val) { m_Commission = val; }

void Pnl::setOperation(const Pnl::type_Operation & val) { m_Operation = val; }

Pnl::type_Operation Pnl::getOperation(bool bLoadFromDatabase, const QString & sAppendRelations /* = QString() */, QSqlDatabase * pDatabase /* = NULL */, QSqlError * pDaoError /* = NULL */)
{
   if (pDaoError) { (* pDaoError) = QSqlError(); }
   if (! bLoadFromDatabase) { return getOperation(); }
   QString sRelation = "{Id} | Operation";
   if (! sAppendRelations.isEmpty() && ! sAppendRelations.startsWith("->") && ! sAppendRelations.startsWith(">>")) { sRelation += "->" + sAppendRelations; }
   else if (! sAppendRelations.isEmpty()) { sRelation += sAppendRelations; }
   trdk::FrontEnd::Orm::Pnl tmp;
   tmp.m_Id = this->m_Id;
   QSqlError daoError = qx::dao::fetch_by_id_with_relation(sRelation, tmp, pDatabase);
   if (! daoError.isValid()) { this->m_Operation = tmp.m_Operation; }
   if (pDaoError) { (* pDaoError) = daoError; }
   return m_Operation;
}

} // namespace Orm
} // namespace FrontEnd
} // namespace trdk
