/************************************************************************************************
** File created by QxEntityEditor 1.2.2 (2018/04/18 19:51) : please, do NOT modify this file ! **
************************************************************************************************/

#include "../include/Trdk_FrontEnd_Lib_Orm_precompiled_header.gen.h"

#include "../include/trdk_FrontEnd_Orm_StrategyInstance.gen.h"
#include "../include/trdk_FrontEnd_Orm_Operation.gen.h"

#include <QxOrm_Impl.h>

QX_REGISTER_COMPLEX_CLASS_NAME_CPP_TRDK_FRONTEND_LIB_ORM(trdk::FrontEnd::Orm::StrategyInstance, trdk_FrontEnd_Orm_StrategyInstance)

namespace qx {

template <>
void register_class(QxClass<trdk::FrontEnd::Orm::StrategyInstance> & t)
{
   qx::IxDataMember * pData = NULL; Q_UNUSED(pData);
   qx::IxSqlRelation * pRelation = NULL; Q_UNUSED(pRelation);
   qx::IxFunction * pFct = NULL; Q_UNUSED(pFct);
   qx::IxValidator * pValidator = NULL; Q_UNUSED(pValidator);

   t.setName("strategy_instance");

   pData = t.id(& trdk::FrontEnd::Orm::StrategyInstance::m_Id, "Id", 0);
   pData->setName("id");

   pData = t.data(& trdk::FrontEnd::Orm::StrategyInstance::m_TypeId, "TypeId", 0, true, true);
   pData->setName("type_id");
   pData->setIsIndex(true);
   pData = t.data(& trdk::FrontEnd::Orm::StrategyInstance::m_Name, "Name", 0, true, true);
   pData->setName("name");
   pData->setIsIndex(true);
   pData = t.data(& trdk::FrontEnd::Orm::StrategyInstance::m_IsActive, "IsActive", 0, true, true);
   pData->setName("is_active");
   pData->setIsIndex(true);
   pData = t.data(& trdk::FrontEnd::Orm::StrategyInstance::m_Config, "Config", 0, true, true);
   pData->setName("config");

   pRelation = t.relationOneToMany(& trdk::FrontEnd::Orm::StrategyInstance::m_Operations, "Operations", "StrategyInstance", 0);
   pRelation->getDataMember()->setName("operations");

   qx::QxValidatorX<trdk::FrontEnd::Orm::StrategyInstance> * pAllValidator = t.getAllValidator(); Q_UNUSED(pAllValidator);
}

} // namespace qx

namespace trdk {
namespace FrontEnd {
namespace Orm {

StrategyInstance::StrategyInstance() : m_IsActive(false) { ; }

StrategyInstance::StrategyInstance(const QUuid & id) : m_Id(id), m_IsActive(false) { ; }

StrategyInstance::~StrategyInstance() { ; }

QUuid StrategyInstance::getId() const { return m_Id; }

QUuid StrategyInstance::getTypeId() const { return m_TypeId; }

QString StrategyInstance::getName() const { return m_Name; }

bool StrategyInstance::getIsActive() const { return m_IsActive; }

QString StrategyInstance::getConfig() const { return m_Config; }

StrategyInstance::type_Operations StrategyInstance::getOperations() const { return m_Operations; }

StrategyInstance::type_Operations & StrategyInstance::Operations() { return m_Operations; }

const StrategyInstance::type_Operations & StrategyInstance::Operations() const { return m_Operations; }

void StrategyInstance::setId(const QUuid & val) { m_Id = val; }

void StrategyInstance::setTypeId(const QUuid & val) { m_TypeId = val; }

void StrategyInstance::setName(const QString & val) { m_Name = val; }

void StrategyInstance::setIsActive(const bool & val) { m_IsActive = val; }

void StrategyInstance::setConfig(const QString & val) { m_Config = val; }

void StrategyInstance::setOperations(const StrategyInstance::type_Operations & val) { m_Operations = val; }

StrategyInstance::type_Operations StrategyInstance::getOperations(bool bLoadFromDatabase, const QString & sAppendRelations /* = QString() */, QSqlDatabase * pDatabase /* = NULL */, QSqlError * pDaoError /* = NULL */)
{
   if (pDaoError) { (* pDaoError) = QSqlError(); }
   if (! bLoadFromDatabase) { return getOperations(); }
   QString sRelation = "{Id} | Operations";
   if (! sAppendRelations.isEmpty() && ! sAppendRelations.startsWith("->") && ! sAppendRelations.startsWith(">>")) { sRelation += "->" + sAppendRelations; }
   else if (! sAppendRelations.isEmpty()) { sRelation += sAppendRelations; }
   trdk::FrontEnd::Orm::StrategyInstance tmp;
   tmp.m_Id = this->m_Id;
   QSqlError daoError = qx::dao::fetch_by_id_with_relation(sRelation, tmp, pDatabase);
   if (! daoError.isValid()) { this->m_Operations = tmp.m_Operations; }
   if (pDaoError) { (* pDaoError) = daoError; }
   return m_Operations;
}

StrategyInstance::type_Operations & StrategyInstance::Operations(bool bLoadFromDatabase, const QString & sAppendRelations /* = QString() */, QSqlDatabase * pDatabase /* = NULL */, QSqlError * pDaoError /* = NULL */)
{
   if (pDaoError) { (* pDaoError) = QSqlError(); }
   if (! bLoadFromDatabase) { return Operations(); }
   QString sRelation = "{Id} | Operations";
   if (! sAppendRelations.isEmpty() && ! sAppendRelations.startsWith("->") && ! sAppendRelations.startsWith(">>")) { sRelation += "->" + sAppendRelations; }
   else if (! sAppendRelations.isEmpty()) { sRelation += sAppendRelations; }
   trdk::FrontEnd::Orm::StrategyInstance tmp;
   tmp.m_Id = this->m_Id;
   QSqlError daoError = qx::dao::fetch_by_id_with_relation(sRelation, tmp, pDatabase);
   if (! daoError.isValid()) { this->m_Operations = tmp.m_Operations; }
   if (pDaoError) { (* pDaoError) = daoError; }
   return m_Operations;
}

} // namespace Orm
} // namespace FrontEnd
} // namespace trdk
