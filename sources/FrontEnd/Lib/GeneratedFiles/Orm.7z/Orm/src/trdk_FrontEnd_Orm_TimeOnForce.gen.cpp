/************************************************************************************************
** File created by QxEntityEditor 1.2.2 (2018/04/17 19:05) : please, do NOT modify this file ! **
************************************************************************************************/

#include "../include/Trdk_FrontEnd_Lib_Orm_precompiled_header.gen.h"

#include "../include/trdk_FrontEnd_Orm_TimeOnForce.gen.h"

#include <QxOrm_Impl.h>

namespace trdk {
namespace FrontEnd {
namespace Orm {

TimeOnForce::TimeOnForce() { ; }

TimeOnForce::~TimeOnForce() { ; }

} // namespace Orm
} // namespace FrontEnd
} // namespace trdk
