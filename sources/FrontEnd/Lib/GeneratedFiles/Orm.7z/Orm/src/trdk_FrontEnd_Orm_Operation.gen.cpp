/************************************************************************************************
** File created by QxEntityEditor 1.2.2 (2018/04/18 19:51) : please, do NOT modify this file ! **
************************************************************************************************/

#include "../include/Trdk_FrontEnd_Lib_Orm_precompiled_header.gen.h"

#include "../include/trdk_FrontEnd_Orm_Operation.gen.h"
#include "../include/trdk_FrontEnd_Orm_StrategyInstance.gen.h"
#include "../include/trdk_FrontEnd_Orm_Order.gen.h"
#include "../include/trdk_FrontEnd_Orm_Pnl.gen.h"

#include <QxOrm_Impl.h>

QX_REGISTER_COMPLEX_CLASS_NAME_CPP_TRDK_FRONTEND_LIB_ORM(trdk::FrontEnd::Orm::Operation, trdk_FrontEnd_Orm_Operation)

namespace qx {

template <>
void register_class(QxClass<trdk::FrontEnd::Orm::Operation> & t)
{
   qx::IxDataMember * pData = NULL; Q_UNUSED(pData);
   qx::IxSqlRelation * pRelation = NULL; Q_UNUSED(pRelation);
   qx::IxFunction * pFct = NULL; Q_UNUSED(pFct);
   qx::IxValidator * pValidator = NULL; Q_UNUSED(pValidator);

   t.setName("operation");

   pData = t.id(& trdk::FrontEnd::Orm::Operation::m_Id, "Id", 0);
   pData->setName("id");

   pData = t.data(& trdk::FrontEnd::Orm::Operation::m_Status, "Status", 0, true, true);
   pData->setName("status");
   pData->setIsIndex(true);
   pData = t.data(& trdk::FrontEnd::Orm::Operation::m_StartTime, "StartTime", 0, true, true);
   pData->setName("start_time");
   pData->setIsIndex(true);
   pData = t.data(& trdk::FrontEnd::Orm::Operation::m_EndTime, "EndTime", 0, true, true);
   pData->setName("end_time");
   pData->setIsIndex(true);

   pRelation = t.relationManyToOne(& trdk::FrontEnd::Orm::Operation::m_StrategyInstance, "StrategyInstance", 0);
   pRelation->getDataMember()->setName("strategyInstance");
   pRelation = t.relationOneToMany(& trdk::FrontEnd::Orm::Operation::m_Orders, "Orders", "Operation", 0);
   pRelation->getDataMember()->setName("orders");
   pRelation = t.relationOneToMany(& trdk::FrontEnd::Orm::Operation::m_Pnl, "Pnl", "Operation", 0);

   qx::QxValidatorX<trdk::FrontEnd::Orm::Operation> * pAllValidator = t.getAllValidator(); Q_UNUSED(pAllValidator);
}

} // namespace qx

namespace trdk {
namespace FrontEnd {
namespace Orm {

Operation::Operation() : m_Status(trdk::FrontEnd::Orm::OperationStatus::ACTIVE) { ; }

Operation::Operation(const QUuid & id) : m_Id(id), m_Status(trdk::FrontEnd::Orm::OperationStatus::ACTIVE) { ; }

Operation::~Operation() { ; }

QUuid Operation::getId() const { return m_Id; }

trdk::FrontEnd::Orm::OperationStatus::enum_OperationStatus Operation::getStatus() const { return m_Status; }

QDateTime Operation::getStartTime() const { return m_StartTime; }

QDateTime Operation::getEndTime() const { return m_EndTime; }

Operation::type_StrategyInstance Operation::getStrategyInstance() const { return m_StrategyInstance; }

Operation::type_Orders Operation::getOrders() const { return m_Orders; }

Operation::type_Orders & Operation::Orders() { return m_Orders; }

const Operation::type_Orders & Operation::Orders() const { return m_Orders; }

Operation::type_Pnl Operation::getPnl() const { return m_Pnl; }

Operation::type_Pnl & Operation::Pnl() { return m_Pnl; }

const Operation::type_Pnl & Operation::Pnl() const { return m_Pnl; }

void Operation::setId(const QUuid & val) { m_Id = val; }

void Operation::setStatus(const trdk::FrontEnd::Orm::OperationStatus::enum_OperationStatus & val) { m_Status = val; }

void Operation::setStartTime(const QDateTime & val) { m_StartTime = val; }

void Operation::setEndTime(const QDateTime & val) { m_EndTime = val; }

void Operation::setStrategyInstance(const Operation::type_StrategyInstance & val) { m_StrategyInstance = val; }

void Operation::setOrders(const Operation::type_Orders & val) { m_Orders = val; }

void Operation::setPnl(const Operation::type_Pnl & val) { m_Pnl = val; }

Operation::type_StrategyInstance Operation::getStrategyInstance(bool bLoadFromDatabase, const QString & sAppendRelations /* = QString() */, QSqlDatabase * pDatabase /* = NULL */, QSqlError * pDaoError /* = NULL */)
{
   if (pDaoError) { (* pDaoError) = QSqlError(); }
   if (! bLoadFromDatabase) { return getStrategyInstance(); }
   QString sRelation = "{Id} | StrategyInstance";
   if (! sAppendRelations.isEmpty() && ! sAppendRelations.startsWith("->") && ! sAppendRelations.startsWith(">>")) { sRelation += "->" + sAppendRelations; }
   else if (! sAppendRelations.isEmpty()) { sRelation += sAppendRelations; }
   trdk::FrontEnd::Orm::Operation tmp;
   tmp.m_Id = this->m_Id;
   QSqlError daoError = qx::dao::fetch_by_id_with_relation(sRelation, tmp, pDatabase);
   if (! daoError.isValid()) { this->m_StrategyInstance = tmp.m_StrategyInstance; }
   if (pDaoError) { (* pDaoError) = daoError; }
   return m_StrategyInstance;
}

Operation::type_Orders Operation::getOrders(bool bLoadFromDatabase, const QString & sAppendRelations /* = QString() */, QSqlDatabase * pDatabase /* = NULL */, QSqlError * pDaoError /* = NULL */)
{
   if (pDaoError) { (* pDaoError) = QSqlError(); }
   if (! bLoadFromDatabase) { return getOrders(); }
   QString sRelation = "{Id} | Orders";
   if (! sAppendRelations.isEmpty() && ! sAppendRelations.startsWith("->") && ! sAppendRelations.startsWith(">>")) { sRelation += "->" + sAppendRelations; }
   else if (! sAppendRelations.isEmpty()) { sRelation += sAppendRelations; }
   trdk::FrontEnd::Orm::Operation tmp;
   tmp.m_Id = this->m_Id;
   QSqlError daoError = qx::dao::fetch_by_id_with_relation(sRelation, tmp, pDatabase);
   if (! daoError.isValid()) { this->m_Orders = tmp.m_Orders; }
   if (pDaoError) { (* pDaoError) = daoError; }
   return m_Orders;
}

Operation::type_Orders & Operation::Orders(bool bLoadFromDatabase, const QString & sAppendRelations /* = QString() */, QSqlDatabase * pDatabase /* = NULL */, QSqlError * pDaoError /* = NULL */)
{
   if (pDaoError) { (* pDaoError) = QSqlError(); }
   if (! bLoadFromDatabase) { return Orders(); }
   QString sRelation = "{Id} | Orders";
   if (! sAppendRelations.isEmpty() && ! sAppendRelations.startsWith("->") && ! sAppendRelations.startsWith(">>")) { sRelation += "->" + sAppendRelations; }
   else if (! sAppendRelations.isEmpty()) { sRelation += sAppendRelations; }
   trdk::FrontEnd::Orm::Operation tmp;
   tmp.m_Id = this->m_Id;
   QSqlError daoError = qx::dao::fetch_by_id_with_relation(sRelation, tmp, pDatabase);
   if (! daoError.isValid()) { this->m_Orders = tmp.m_Orders; }
   if (pDaoError) { (* pDaoError) = daoError; }
   return m_Orders;
}

Operation::type_Pnl Operation::getPnl(bool bLoadFromDatabase, const QString & sAppendRelations /* = QString() */, QSqlDatabase * pDatabase /* = NULL */, QSqlError * pDaoError /* = NULL */)
{
   if (pDaoError) { (* pDaoError) = QSqlError(); }
   if (! bLoadFromDatabase) { return getPnl(); }
   QString sRelation = "{Id} | Pnl";
   if (! sAppendRelations.isEmpty() && ! sAppendRelations.startsWith("->") && ! sAppendRelations.startsWith(">>")) { sRelation += "->" + sAppendRelations; }
   else if (! sAppendRelations.isEmpty()) { sRelation += sAppendRelations; }
   trdk::FrontEnd::Orm::Operation tmp;
   tmp.m_Id = this->m_Id;
   QSqlError daoError = qx::dao::fetch_by_id_with_relation(sRelation, tmp, pDatabase);
   if (! daoError.isValid()) { this->m_Pnl = tmp.m_Pnl; }
   if (pDaoError) { (* pDaoError) = daoError; }
   return m_Pnl;
}

Operation::type_Pnl & Operation::Pnl(bool bLoadFromDatabase, const QString & sAppendRelations /* = QString() */, QSqlDatabase * pDatabase /* = NULL */, QSqlError * pDaoError /* = NULL */)
{
   if (pDaoError) { (* pDaoError) = QSqlError(); }
   if (! bLoadFromDatabase) { return Pnl(); }
   QString sRelation = "{Id} | Pnl";
   if (! sAppendRelations.isEmpty() && ! sAppendRelations.startsWith("->") && ! sAppendRelations.startsWith(">>")) { sRelation += "->" + sAppendRelations; }
   else if (! sAppendRelations.isEmpty()) { sRelation += sAppendRelations; }
   trdk::FrontEnd::Orm::Operation tmp;
   tmp.m_Id = this->m_Id;
   QSqlError daoError = qx::dao::fetch_by_id_with_relation(sRelation, tmp, pDatabase);
   if (! daoError.isValid()) { this->m_Pnl = tmp.m_Pnl; }
   if (pDaoError) { (* pDaoError) = daoError; }
   return m_Pnl;
}

} // namespace Orm
} // namespace FrontEnd
} // namespace trdk
