/************************************************************************************************
** File created by QxEntityEditor 1.2.2 (2018/04/18 21:45) : please, do NOT modify this file ! **
************************************************************************************************/

#include "../include/Trdk_FrontEnd_Lib_Orm_precompiled_header.gen.h"

#include "../include/trdk_FrontEnd_Orm_Order.gen.h"
#include "../include/trdk_FrontEnd_Orm_Operation.gen.h"

#include <QxOrm_Impl.h>

QX_REGISTER_COMPLEX_CLASS_NAME_CPP_TRDK_FRONTEND_LIB_ORM(trdk::FrontEnd::Orm::Order, trdk_FrontEnd_Orm_Order)

namespace qx {

template <>
void register_class(QxClass<trdk::FrontEnd::Orm::Order> & t)
{
   qx::IxDataMember * pData = NULL; Q_UNUSED(pData);
   qx::IxSqlRelation * pRelation = NULL; Q_UNUSED(pRelation);
   qx::IxFunction * pFct = NULL; Q_UNUSED(pFct);
   qx::IxValidator * pValidator = NULL; Q_UNUSED(pValidator);

   t.setName("order_");

   pData = t.id(& trdk::FrontEnd::Orm::Order::m_Id, "Id", 0);
   pData->setName("id");

   pData = t.data(& trdk::FrontEnd::Orm::Order::m_SubOperationId, "SubOperationId", 0, true, true);
   pData->setName("sub_operation_id");
   pData = t.data(& trdk::FrontEnd::Orm::Order::m_RemoteId, "RemoteId", 0, true, true);
   pData->setName("remote_id");
   pData = t.data(& trdk::FrontEnd::Orm::Order::m_OrderTime, "OrderTime", 0, true, true);
   pData->setName("order_time");
   pData = t.data(& trdk::FrontEnd::Orm::Order::m_UpdateTime, "UpdateTime", 0, true, true);
   pData->setName("update_time");
   pData = t.data(& trdk::FrontEnd::Orm::Order::m_Symbol, "Symbol", 0, true, true);
   pData->setName("symbol");
   pData = t.data(& trdk::FrontEnd::Orm::Order::m_Currency, "Currency", 0, true, true);
   pData->setName("currency");
   pData = t.data(& trdk::FrontEnd::Orm::Order::m_TradingSystem, "TradingSystem", 0, true, true);
   pData->setName("trading_system");
   pData = t.data(& trdk::FrontEnd::Orm::Order::m_IsBuy, "IsBuy", 0, true, true);
   pData->setName("is_buy");
   pData = t.data(& trdk::FrontEnd::Orm::Order::m_Qty, "Qty", 0, true, true);
   pData->setName("qty");
   pData = t.data(& trdk::FrontEnd::Orm::Order::m_RemainingQty, "RemainingQty", 0, true, true);
   pData->setName("remaining_qty");
   pData = t.data(& trdk::FrontEnd::Orm::Order::m_Price, "Price", 0, true, true);
   pData->setName("price");
   pData = t.data(& trdk::FrontEnd::Orm::Order::m_Status, "Status", 0, true, true);
   pData->setName("status");
   pData = t.data(& trdk::FrontEnd::Orm::Order::m_TimeInForce, "TimeInForce", 0, true, true);
   pData->setName("time_in_force");
   pData = t.data(& trdk::FrontEnd::Orm::Order::m_AdditionalInfo, "AdditionalInfo", 0, true, true);
   pData->setName("additional_info");

   pRelation = t.relationManyToOne(& trdk::FrontEnd::Orm::Order::m_Operation, "Operation", 0);
   pRelation->getDataMember()->setName("operation");

   qx::QxValidatorX<trdk::FrontEnd::Orm::Order> * pAllValidator = t.getAllValidator(); Q_UNUSED(pAllValidator);
}

} // namespace qx

namespace trdk {
namespace FrontEnd {
namespace Orm {

Order::Order() : m_Id(0), m_SubOperationId(0), m_IsBuy(false), m_Qty(0.0), m_RemainingQty(0), m_Price(0.0), m_Status(0) { ; }

Order::Order(const quint64 & id) : m_Id(id), m_SubOperationId(0), m_IsBuy(false), m_Qty(0.0), m_RemainingQty(0), m_Price(0.0), m_Status(0) { ; }

Order::~Order() { ; }

quint64 Order::getId() const { return m_Id; }

qint64 Order::getSubOperationId() const { return m_SubOperationId; }

QString Order::getRemoteId() const { return m_RemoteId; }

QDateTime Order::getOrderTime() const { return m_OrderTime; }

QDateTime Order::getUpdateTime() const { return m_UpdateTime; }

QString Order::getSymbol() const { return m_Symbol; }

QString Order::getCurrency() const { return m_Currency; }

QString Order::getTradingSystem() const { return m_TradingSystem; }

bool Order::getIsBuy() const { return m_IsBuy; }

double Order::getQty() const { return m_Qty; }

double Order::getRemainingQty() const { return m_RemainingQty; }

double Order::getPrice() const { return m_Price; }

int Order::getStatus() const { return m_Status; }

trdk::FrontEnd::Orm::TimeInForce::enum_TimeInForce Order::getTimeInForce() const { return m_TimeInForce; }

QString Order::getAdditionalInfo() const { return m_AdditionalInfo; }

Order::type_Operation Order::getOperation() const { return m_Operation; }

void Order::setId(const quint64 & val) { m_Id = val; }

void Order::setSubOperationId(const qint64 & val) { m_SubOperationId = val; }

void Order::setRemoteId(const QString & val) { m_RemoteId = val; }

void Order::setOrderTime(const QDateTime & val) { m_OrderTime = val; }

void Order::setUpdateTime(const QDateTime & val) { m_UpdateTime = val; }

void Order::setSymbol(const QString & val) { m_Symbol = val; }

void Order::setCurrency(const QString & val) { m_Currency = val; }

void Order::setTradingSystem(const QString & val) { m_TradingSystem = val; }

void Order::setIsBuy(const bool & val) { m_IsBuy = val; }

void Order::setQty(const double & val) { m_Qty = val; }

void Order::setRemainingQty(const double & val) { m_RemainingQty = val; }

void Order::setPrice(const double & val) { m_Price = val; }

void Order::setStatus(const int & val) { m_Status = val; }

void Order::setTimeInForce(const trdk::FrontEnd::Orm::TimeInForce::enum_TimeInForce & val) { m_TimeInForce = val; }

void Order::setAdditionalInfo(const QString & val) { m_AdditionalInfo = val; }

void Order::setOperation(const Order::type_Operation & val) { m_Operation = val; }

Order::type_Operation Order::getOperation(bool bLoadFromDatabase, const QString & sAppendRelations /* = QString() */, QSqlDatabase * pDatabase /* = NULL */, QSqlError * pDaoError /* = NULL */)
{
   if (pDaoError) { (* pDaoError) = QSqlError(); }
   if (! bLoadFromDatabase) { return getOperation(); }
   QString sRelation = "{Id} | Operation";
   if (! sAppendRelations.isEmpty() && ! sAppendRelations.startsWith("->") && ! sAppendRelations.startsWith(">>")) { sRelation += "->" + sAppendRelations; }
   else if (! sAppendRelations.isEmpty()) { sRelation += sAppendRelations; }
   trdk::FrontEnd::Orm::Order tmp;
   tmp.m_Id = this->m_Id;
   QSqlError daoError = qx::dao::fetch_by_id_with_relation(sRelation, tmp, pDatabase);
   if (! daoError.isValid()) { this->m_Operation = tmp.m_Operation; }
   if (pDaoError) { (* pDaoError) = daoError; }
   return m_Operation;
}

} // namespace Orm
} // namespace FrontEnd
} // namespace trdk
